from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api-auth/", include("rest_framework.urls")),
    path("api/v1/", include("apps.usuarios.urls")),
    path("api/v1/", include("apps.grupos.urls")),
    path("api/v1/", include("apps.integrantes.urls")),
    path("api/v1/", include("apps.albumes.urls")),
    path("api/v1/", include("apps.doramas.urls")),
    path("api/v1/", include("apps.fans.urls")),
]
