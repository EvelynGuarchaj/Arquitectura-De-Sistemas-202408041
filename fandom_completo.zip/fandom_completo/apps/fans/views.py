from .models import Fan
from .serializer import FanSerializer
from rest_framework import generics


class FanLista(generics.ListCreateAPIView):
    queryset = Fan.objects.all()
    serializer_class = FanSerializer


class FanDetalle(generics.RetrieveUpdateDestroyAPIView):
    queryset = Fan.objects.all()
    serializer_class = FanSerializer
