from django.urls import path
from . import views

urlpatterns = [
    path("fans/", views.FanLista.as_view()),
    path("fans/<int:pk>/", views.FanDetalle.as_view()),
]
