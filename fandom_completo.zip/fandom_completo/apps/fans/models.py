from django.db import models
from apps.grupos.models import Grupo
from apps.doramas.models import Dorama


class Fan(models.Model):
    nombre = models.CharField(max_length=100)
    pais = models.CharField(max_length=50)
    grupo_favorito = models.ForeignKey(Grupo, on_delete=models.CASCADE)
    dorama_favorito = models.ForeignKey(Dorama, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre
