from .models import Fan
from rest_framework import serializers


class FanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Fan
        fields = "__all__"
