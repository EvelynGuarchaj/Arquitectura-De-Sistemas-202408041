from .models import Dorama
from rest_framework import serializers


class DoramaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dorama
        fields = "__all__"
