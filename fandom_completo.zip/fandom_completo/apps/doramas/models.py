from django.db import models


class Dorama(models.Model):
    titulo = models.CharField(max_length=150)
    anio_estreno = models.IntegerField()
    capitulos = models.IntegerField()
    calificacion = models.FloatField()

    def __str__(self):
        return self.titulo
