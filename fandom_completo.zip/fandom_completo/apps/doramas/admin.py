from django.contrib import admin
from .models import Dorama

admin.site.register(Dorama)
