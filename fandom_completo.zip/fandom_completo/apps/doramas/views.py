from .models import Dorama
from .serializer import DoramaSerializer
from rest_framework import generics


class DoramaLista(generics.ListCreateAPIView):
    queryset = Dorama.objects.all()
    serializer_class = DoramaSerializer


class DoramaDetalle(generics.RetrieveUpdateDestroyAPIView):
    queryset = Dorama.objects.all()
    serializer_class = DoramaSerializer
