from django.urls import path
from . import views

urlpatterns = [
    path("doramas/", views.DoramaLista.as_view()),
    path("doramas/<int:pk>/", views.DoramaDetalle.as_view()),
]
