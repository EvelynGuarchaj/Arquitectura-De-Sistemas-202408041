from django.db import models


class Grupo(models.Model):
    nombre = models.CharField(max_length=100)
    agencia = models.CharField(max_length=100)
    fecha_debut = models.DateField()
    activo = models.BooleanField(default=True)

    def __str__(self):
        return self.nombre
