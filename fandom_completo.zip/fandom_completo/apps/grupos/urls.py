from django.urls import path
from . import views

urlpatterns = [
    path("grupos/", views.GrupoLista.as_view()),
    path("grupos/<int:pk>/", views.GrupoDetalle.as_view()),
]
