from .models import Grupo
from .serializer import GrupoSerializer
from rest_framework import generics


class GrupoLista(generics.ListCreateAPIView):
    queryset = Grupo.objects.all()
    serializer_class = GrupoSerializer


class GrupoDetalle(generics.RetrieveUpdateDestroyAPIView):
    queryset = Grupo.objects.all()
    serializer_class = GrupoSerializer
