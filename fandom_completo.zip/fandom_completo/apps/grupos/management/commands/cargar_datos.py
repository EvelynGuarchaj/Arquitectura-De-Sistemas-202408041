from django.core.management.base import BaseCommand

from apps.grupos.models import Grupo
from apps.integrantes.models import Integrante
from apps.albumes.models import Album
from apps.doramas.models import Dorama
from apps.fans.models import Fan


class Command(BaseCommand):
    help = "Carga datos de ejemplo"

    def handle(self, *args, **options):
        if Grupo.objects.exists():
            self.stdout.write("Ya hay datos cargados, no se hizo nada.")
            return

        bts = Grupo.objects.create(nombre="BTS", agencia="BIGHIT MUSIC", fecha_debut="2013-06-13")
        txt = Grupo.objects.create(nombre="TXT", agencia="BIGHIT MUSIC", fecha_debut="2019-03-04")
        blackpink = Grupo.objects.create(nombre="BLACKPINK", agencia="YG Entertainment", fecha_debut="2016-08-08")
        enhypen = Grupo.objects.create(nombre="ENHYPEN", agencia="BELIFT LAB", fecha_debut="2020-11-30")
        newjeans = Grupo.objects.create(nombre="NewJeans", agencia="ADOR", fecha_debut="2022-08-01")

        Integrante.objects.create(nombre="RM", fecha_nacimiento="1994-09-12", grupo=bts)
        Integrante.objects.create(nombre="V", fecha_nacimiento="1995-12-30", grupo=bts)
        Integrante.objects.create(nombre="Jungkook", fecha_nacimiento="1997-09-01", grupo=bts)
        Integrante.objects.create(nombre="Soobin", fecha_nacimiento="2000-12-05", grupo=txt)
        Integrante.objects.create(nombre="Beomgyu", fecha_nacimiento="2001-03-13", grupo=txt)
        Integrante.objects.create(nombre="Jennie", fecha_nacimiento="1996-01-16", grupo=blackpink)
        Integrante.objects.create(nombre="Lisa", fecha_nacimiento="1997-03-27", grupo=blackpink)
        Integrante.objects.create(nombre="Sunghoon", fecha_nacimiento="2002-12-08", grupo=enhypen)
        Integrante.objects.create(nombre="Haerin", fecha_nacimiento="2006-05-15", grupo=newjeans)

        Album.objects.create(titulo="Map of the Soul: 7", fecha_lanzamiento="2020-02-21", precio=30, cantidad_canciones=20, grupo=bts)
        Album.objects.create(titulo="The Name Chapter: Temptation", fecha_lanzamiento="2023-01-27", precio=25, cantidad_canciones=5, grupo=txt)
        Album.objects.create(titulo="Born Pink", fecha_lanzamiento="2022-09-16", precio=28, cantidad_canciones=8, grupo=blackpink)
        Album.objects.create(titulo="Dark Blood", fecha_lanzamiento="2023-05-22", precio=25, cantidad_canciones=6, grupo=enhypen)
        Album.objects.create(titulo="Get Up", fecha_lanzamiento="2023-07-21", precio=22, cantidad_canciones=6, grupo=newjeans)

        flores = Dorama.objects.create(titulo="Los chicos son mejores que las flores", anio_estreno=2009, capitulos=25, calificacion=8.2)
        hermosa = Dorama.objects.create(titulo="Eres hermosa", anio_estreno=2009, capitulos=16, calificacion=8.5)
        inmortal = Dorama.objects.create(titulo="El ser inmortal", anio_estreno=2016, capitulos=16, calificacion=9.0)
        Dorama.objects.create(titulo="Love Alarm", anio_estreno=2019, capitulos=8, calificacion=7.4)

        Fan.objects.create(nombre="Yaniz", pais="Guatemala", grupo_favorito=txt, dorama_favorito=inmortal)
        Fan.objects.create(nombre="Evelyn", pais="Guatemala", grupo_favorito=newjeans, dorama_favorito=hermosa)
        Fan.objects.create(nombre="Beomgyu", pais="México", grupo_favorito=enhypen, dorama_favorito=flores)

        self.stdout.write(self.style.SUCCESS("Datos cargados."))
