from .models import Integrante
from .serializer import IntegranteSerializer
from rest_framework import generics


class IntegranteLista(generics.ListCreateAPIView):
    queryset = Integrante.objects.all()
    serializer_class = IntegranteSerializer


class IntegranteDetalle(generics.RetrieveUpdateDestroyAPIView):
    queryset = Integrante.objects.all()
    serializer_class = IntegranteSerializer
