from django.urls import path
from . import views

urlpatterns = [
    path("integrantes/", views.IntegranteLista.as_view()),
    path("integrantes/<int:pk>/", views.IntegranteDetalle.as_view()),
]
