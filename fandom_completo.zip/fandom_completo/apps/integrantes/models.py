from django.db import models
from apps.grupos.models import Grupo


class Integrante(models.Model):
    nombre = models.CharField(max_length=100)
    fecha_nacimiento = models.DateField()
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre
