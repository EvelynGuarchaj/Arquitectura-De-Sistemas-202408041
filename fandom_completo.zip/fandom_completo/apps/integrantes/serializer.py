from .models import Integrante
from rest_framework import serializers


class IntegranteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Integrante
        fields = "__all__"
