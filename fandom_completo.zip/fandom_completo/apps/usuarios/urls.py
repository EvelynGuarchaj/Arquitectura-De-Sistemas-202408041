from django.urls import path
from . import views

urlpatterns = [
    path("registro/", views.Registro.as_view()),
    path("login/", views.Login.as_view()),
    path("login/renovar/", views.RenovarToken.as_view()),
    path("perfil/", views.Perfil.as_view()),
]
