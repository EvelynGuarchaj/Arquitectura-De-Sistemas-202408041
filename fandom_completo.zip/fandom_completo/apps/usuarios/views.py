from django.contrib.auth.models import User
from rest_framework import generics
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .serializer import RegistroSerializer, PerfilSerializer


class Registro(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegistroSerializer
    permission_classes = [AllowAny]


# Recibe username y password, devuelve los tokens access y refresh
class Login(TokenObtainPairView):
    pass


class RenovarToken(TokenRefreshView):
    pass


# Devuelve los datos del usuario dueño del token
class Perfil(generics.RetrieveAPIView):
    serializer_class = PerfilSerializer

    def get_object(self):
        return self.request.user
