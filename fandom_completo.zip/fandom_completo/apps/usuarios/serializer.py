from django.contrib.auth.models import User
from rest_framework import serializers


class RegistroSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)

    class Meta:
        model = User
        fields = ["id", "username", "email", "password"]

    # create_user guarda la contraseña encriptada
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class PerfilSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "email"]
