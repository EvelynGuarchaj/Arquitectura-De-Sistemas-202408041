from django.db import models
from apps.grupos.models import Grupo


class Album(models.Model):
    titulo = models.CharField(max_length=150)
    fecha_lanzamiento = models.DateField()
    precio = models.DecimalField(max_digits=6, decimal_places=2)
    cantidad_canciones = models.IntegerField()
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE)

    def __str__(self):
        return self.titulo
