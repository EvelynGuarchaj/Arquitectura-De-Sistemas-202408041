from django.urls import path
from . import views

urlpatterns = [
    path("albumes/", views.AlbumLista.as_view()),
    path("albumes/<int:pk>/", views.AlbumDetalle.as_view()),
]
